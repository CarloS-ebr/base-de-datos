import { Hono } from 'hono';
import { db } from './src/db/index';
import { actors } from './src/db/schema';

const app = new Hono();

// Ruta GET /actors
app.get('/actors', async (c) => {
  try {
    const result = await db.select().from(actors).execute();
    return c.json(result);
  } catch (error) {
    console.error('Database error:', error);
    return c.json({ error: 'Error al obtener actores' }, 500);
  }
});

// Ruta GET /films
app.get('/films', async (c) => {
  try {
    const result = await db.select().from(films).execute();
    return c.json(result);
  } catch (error) {
    console.error('Database error:', error);
    return c.json({ error: 'Error al obtener películas' }, 500);
  }
});

export default app;
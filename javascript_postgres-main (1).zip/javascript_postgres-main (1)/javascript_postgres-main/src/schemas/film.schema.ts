import { z } from 'zod';

export const FilmSchema = z.object({
    title: z.string(),
    description: z.string(),
    rental_duration: z.number()
});

export type FilmInput = z.infer<typeof FilmSchema>;
import { Hono } from 'hono';
import { FilmSchema, type FilmInput } from '../schemas/film.schema';
import { FilmController } from '../controllers/film.controller';
import { validateBody } from '../middlewares/validate';

const filmRouter = new Hono();

filmRouter.get('/films', async (): Promise<Response> => {
    const { status, body } = await FilmController.getAll();
    return new Response(JSON.stringify(body), {
        status: status,
        headers: { 'Content-Type': 'application/json' }
    });
});

filmRouter.get('/films/:id', async (c): Promise<Response> => {
    const id = Number(c.req.param('id'));
    const { status, body } = await FilmController.getById(id);
    return new Response(JSON.stringify(body), {
        status: status,
        headers: { 'Content-Type': 'application/json' }
    });
});

filmRouter.post(
    '/films',
    validateBody(FilmSchema),
    async (c): Promise<Response> => {
        const bodyValidated = c.get('validatedBody') as FilmInput;
        const { status, body } = await FilmController.add(bodyValidated);
        return new Response(JSON.stringify(body), {
            status: status,
            headers: { 'Content-Type': 'application/json' }
        });
    }
);

export default filmRouter;
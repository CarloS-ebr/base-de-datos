package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SurveyDAO dao = new SurveyDAO();

        while (true) {
            System.out.println("\n--- MENÚ DE ENCUESTAS ---");
            System.out.println("1. Agregar encuesta");
            System.out.println("2. Listar encuestas");
            System.out.println("3. Actualizar encuesta");
            System.out.println("4. Eliminar encuesta");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = sc.nextInt(); sc.nextLine();
                    System.out.print("Respuesta (Sí / No / Tal vez): ");
                    String respuesta = sc.nextLine();
                    dao.agregarEncuesta(new Survey(nombre, edad, respuesta));
                    break;
                case 2:
                    dao.listarEncuestas();
                    break;
                case 3:
                    dao.listarEncuestas();
                    System.out.print("Índice a actualizar (1-n): ");
                    int idxA = sc.nextInt(); sc.nextLine();
                    System.out.print("Nuevo nombre: ");
                    String nuevoNombre = sc.nextLine();
                    System.out.print("Nueva edad: ");
                    int nuevaEdad = sc.nextInt(); sc.nextLine();
                    System.out.print("Nueva respuesta: ");
                    String nuevaRespuesta = sc.nextLine();
                    dao.actualizarEncuesta(idxA - 1, new Survey(nuevoNombre, nuevaEdad, nuevaRespuesta));
                    break;
                case 4:
                    dao.listarEncuestas();
                    System.out.print("Índice a eliminar (1-n): ");
                    int idxE = sc.nextInt(); sc.nextLine();
                    dao.eliminarEncuesta(idxE - 1);
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
}

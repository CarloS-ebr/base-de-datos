package org.example;

public class Survey {
    private String nombre;
    private int edad;
    private String respuesta;

    public Survey(String nombre, int edad, String respuesta) {
        this.nombre = nombre;
        this.edad = edad;
        this.respuesta = respuesta;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Edad: " + edad + ", Respuesta: " + respuesta;
    }
}

package org.example;

import java.util.ArrayList;
import java.util.List;

public class SurveyDAO {
    private List<Survey> surveys = new ArrayList<>();

    public void agregarEncuesta(Survey survey) {
        surveys.add(survey);
        System.out.println("Encuesta agregada.");
    }

    public void listarEncuestas() {
        if (surveys.isEmpty()) {
            System.out.println("No hay encuestas registradas.");
        } else {
            for (int i = 0; i < surveys.size(); i++) {
                System.out.println((i + 1) + ". " + surveys.get(i));
            }
        }
    }

    public void actualizarEncuesta(int index, Survey nueva) {
        if (index >= 0 && index < surveys.size()) {
            surveys.set(index, nueva);
            System.out.println("Encuesta actualizada.");
        } else {
            System.out.println("Índice no válido.");
        }
    }

    public void eliminarEncuesta(int index) {
        if (index >= 0 && index < surveys.size()) {
            surveys.remove(index);
            System.out.println("Encuesta eliminada.");
        } else {
            System.out.println("Índice no válido.");
        }
    }
}

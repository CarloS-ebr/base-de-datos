package org.example;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SurveyDAO {
    private List<Survey> encuestas = new ArrayList<>();

    public void agregarEncuesta(Survey encuesta) {
        encuestas.add(encuesta);
        System.out.println("Encuesta agregada correctamente.");
    }

    public void mostrarEncuestas() {
        if (encuestas.isEmpty()) {
            System.out.println("No hay encuestas registradas.");
        } else {
            for (Survey encuesta : encuestas) {
                System.out.println(encuesta);
            }
        }
    }

    public void eliminarEncuesta(int id) {
        Iterator<Survey> iterator = encuestas.iterator();
        boolean encontrada = false;
        while (iterator.hasNext()) {
            Survey encuesta = iterator.next();
            if (encuesta.getId() == id) {
                iterator.remove();
                System.out.println("Encuesta eliminada.");
                encontrada = true;
                break;
            }
        }
        if (!encontrada) {
            System.out.println("No se encontró una encuesta con ese ID.");
        }
    }
}

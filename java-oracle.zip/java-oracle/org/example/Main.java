package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SurveyDAO dao = new SurveyDAO();
        while (true) {
            System.out.println("\n--- Menú de Encuestas ---");
            System.out.println("1. Agregar encuesta");
            System.out.println("2. Mostrar encuestas");
            System.out.println("3. Eliminar encuesta por ID");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Nombre del encuestado: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Edad: ");
                    int edad = scanner.nextInt();
                    scanner.nextLine(); // limpiar buffer
                    System.out.print("Opinión: ");
                    String opinion = scanner.nextLine();
                    dao.agregarEncuesta(new Survey(nombre, edad, opinion));
                    break;
                case 2:
                    dao.mostrarEncuestas();
                    break;
                case 3:
                    System.out.print("ID de la encuesta a eliminar: ");
                    int id = scanner.nextInt();
                    dao.eliminarEncuesta(id);
                    break;
                case 4:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}

package org.example;

public class Survey {
    private static int contador = 1;
    private int id;
    private String nombre;
    private int edad;
    private String opinion;

    public Survey(String nombre, int edad, String opinion) {
        this.id = contador++;
        this.nombre = nombre;
        this.edad = edad;
        this.opinion = opinion;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Edad: " + edad + ", Opinión: " + opinion;
    }
}
